const focim = document.createElement("h1");
focim.id = "focim";
focim.textContent = "Massospondylus";
focim.style.textAlign = "center";

const alcim = document.createElement("h4");
alcim.id = "alcim";
alcim.textContent = "Massospondylus";
alcim.style.textAlign = "Center";

const vonal = document.createElement("hr")

const szoveg = document.createElement("p");
szoveg.id = "szoveg"

szoveg.textContent = `
A Massospondylus (ógörög eredetű nevének jelentése 'megnyúlt gerinc') a prosauropoda dinoszauruszok egyik neme, amely a kora jura kor hettangi – pliensbachi korszakában, mintegy 200–183 millió évvel ezelőtt élt. Ez az egyik legelsőként elnevezett dinoszaurusz, a holotípusát Richard Owen írta le 1854-ben, egy Dél-Afrikában talált lelet alapján. Azóta Dél-Afrika más részein, Lesothóban és Zimbabwében is megtalálták a fosszíliáit. Az Arizona állambeli Kayenta-formációból, Indiából és Argentínából is kerültek elő olyan maradványok, amelyeket a Massospondylushoz kapcsoltak, de elképzelhető, hogy ezek a leletek nem ehhez a nemhez tartoznak.`;

const szoveg2 = document.createElement("p");
szoveg2.id = "szoveg2";
szoveg2.textContent = `
Típusfaja a M. carinatus, de a felfedezése utáni 150 évben további hét fajt is elneveztek, melyek közül jelenleg csak a M. kalae számít érvényesnek. Ezen időszak utolsó éveiben a prosauropodák rendszertana sokat változott, és számos tudós vitatni kezdte, hogy a Massospondylust a dinoszauruszok evolúciós fájának megfelelő pontján helyezték-e el. A nem számára megalkotott családnév, a Massospondylidae érvényessége a prosauropodák kapcsolatainak változásai miatt szintén vitatottá vált. Nem világos az sem, hogy mely más dinoszauruszokkal tartozott egy csoportba (amennyiben voltak ilyenek); de a családot több 2007-ben megjelent cikk is érvényesnek tekinti.`;

const szoveg3 = document.createElement("p");
szoveg3.id = "szoveg3";
szoveg3.textContent = `
Valószínűleg növényevő volt, bár létezik olyan elképzelés, ami szerint prosauropodák mindenevők voltak. Karcsú testtel, hosszú nyakkal és farokkal rendelkezett, mellső lábainak hüvelykujjain éles karmok helyezkedtek el, melyeket a táplálkozás vagy esetleg a védekezés során használhatott. Néhány újabb vizsgálat szerint a Massospondylus folyamatosan növekedett egész életében, testében a madarakéhoz hasonló légzsákok voltak, és feltehetően gondozta az utódait.`;

const szoveg4 = document.createElement("p");
szoveg3.id = "szoveg4";
szoveg3.textContent = `
A Massospondylus közepes méretű prosauropoda volt, testhossza körülbelül 4–[1][2][3] 6[4][5] méter, tömege mintegy 135[3]-250[6] kilogramm lehetett. Habár sokáig négy lábon járó állatként ábrázolták, egy 2007-ben, a mellső lábakon elvégzett anatómiai vizsgálat megállapította, hogy a két végtag mozgásának korlátozottsága megnehezíthette ezt a járásmódot. Emellett a vizsgálat kizárta az ujjízületeken való járás valószínűségét és a helyváltoztatás más módjait is, arra hivatkozva, hogy a Massospondylus csak korlátozott mértéken volt képes megcsavarni a mellső végtagjait. Ezért, még ha a tömege alapján négy lábon járónak tűnik is, kénytelen volt a hátsó lábain mozogni.[7]`;

const szoveg5 = document.createElement("p");
szoveg3.id = "szoveg5";
szoveg3.textContent = `
A Massospondylus ennek ellenére a legtöbb szempontból átlagos prosauropoda volt. Karcsú testtel, kis fejjel, hosszú nyakkal és farokkal rendelkezett. Nyakát 9, hátát 13, keresztcsontját 3, farkát pedig 40 csigolya alkotta. Szeméremcsontja – a hüllőmedencéjűekre jellemző módon – előre irányult. Könnyebb testfelépítésű volt, mint a hozzá hasonló Plateosaurus.[8] Egy újabb felfedezés alapján a Massospondylus jól fejlett kulcscsontokkal rendelkezett, melyek a villacsonthoz hasonlóan összekapcsolódva helyezkedtek el, így valószínűleg nem volt képes mozgatni a vállait, de maguk a kulcscsontok mégsem voltak olyan fejletlenek és használhatatlanok, mint azoknál a dinoszauruszoknál, amelyeknek nincs igazi villacsontjuk. Ez a felfedezés azt is jelzi, hogy a madarak villacsontja a kulcscsontokból alakult ki.[9]`;

const szoveg6 = document.createElement("p");
szoveg3.id = "szove6";
szoveg3.textContent = `
A Plateosaurushoz hasonlóan minden lábán öt ujja volt, a hüvelykujjain pedig nagy karmokat viselt, amiket feltehetően táplálkozásra vagy a ragadozókkal szembeni védekezésre használt. A mellső láb negyedik és ötödik ujja kisebb volt, aszimmetrikus látszatot keltett. A 2007-es vizsgálat megállapította, hogy a kéztartás félig szupinált („imádkozó tartás”) volt, a tenyerek egymás felé fordultak; a csuklókat sosem találták meg elfordított helyzetben a még ízelt (kapcsolódó részekből álló) fosszíliáknál.[7]`;

const gomb = document.createElement("button");
gomb.id = "gomb";
gomb.textContent = "Kattints!";


document.body.appendChild(focim);
document.body.appendChild(alcim);
document.body.appendChild(vonal);
document.body.appendChild(szoveg);
document.body.appendChild(szoveg2);
document.body.appendChild(szoveg3);
document.body.appendChild(szoveg4);
document.body.appendChild(szoveg5);
document.body.appendChild(szoveg6);
document.body.appendChild(gomb);